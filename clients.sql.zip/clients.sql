-- phpMyAdmin SQL Dump
-- version 5.2.1deb3
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : dim. 21 juil. 2024 à 23:48
-- Version du serveur : 8.0.37-0ubuntu0.24.04.1
-- Version de PHP : 8.2.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `gestionClient`
--

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE `clients` (
  `id` int NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `status` enum('active','inactive') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `clients`
--

INSERT INTO `clients` (`id`, `name`, `email`, `phone`, `address`, `gender`, `status`) VALUES
(1, 'Jade Browning', 'vuhasuhi@mailinator.com', '778328238', 'Liberté 6 Dakar', 'female', 'active'),
(2, 'Jade Browning', 'vuhasuhi@mailinator.com', '7713881283', 'Liberté 5/B DAKAR', 'male', 'active'),
(3, 'Jade Browning', 'vuhasuhi@mailinator.com', '', '', 'male', 'active'),
(4, 'Demetria Carrillo', 'qulesexygu@mailinator.com', '', '', 'male', 'active'),
(5, 'Demetria Carrillo', 'qulesexygu@mailinator.com', '', '', 'male', 'active'),
(6, 'Demetria Carrillo', 'qulesexygu@mailinator.com', '', '', 'male', 'active'),
(7, 'uhohoioib', 'bnouibi@jba.com', '', '', 'male', 'active'),
(8, 'uhohoioib', 'bnouibi@jba.com', '', '', 'male', 'active'),
(9, 'Demetria Carrillo', 'qulesexygu@mailinator.com', '', '', 'male', 'active'),
(10, 'Adara Guzman', 'qodo@mailinator.com', '', '', 'male', 'active'),
(11, 'Adara Guzman', 'qodo@mailinator.com', '', '', 'male', 'active'),
(12, 'Xantha Pruitt', 'faxowu@mailinator.com', '', '', 'male', 'active'),
(13, 'Xantha Pruitt', 'faxowu@mailinator.com', '', '', 'male', 'active'),
(14, 'Colin Dale', 'gowy@mailinator.com', '', '', 'male', 'active'),
(15, 'Colin Dale', 'gowy@mailinator.com', '', '', 'male', 'active'),
(16, 'Abigail Hurley', 'vitoj@mailinator.com', '', '', 'male', 'active'),
(17, 'Abigail Hurley', 'vitoj@mailinator.com', '', '', 'male', 'active'),
(18, 'Abigail Hurley', 'vitoj@mailinator.com', '', '', 'male', 'active'),
(19, 'Seydina Mouhammad Diop', 'mouhaleecr7@gmail.com', '', '', 'male', 'active'),
(20, 'uhohoioib', 'bnouibi@jba.com', '', '', 'male', 'active'),
(21, 'Declan Sharpe', 'qosop@mailinator.com', '', '', 'male', 'active'),
(22, 'Damian Adkins 12345', 'qubuga@mailinator.com', '', '', 'male', 'active'),
(23, 'Kirk Walker', 'gyma@mailinator.com', '', '', 'male', 'active'),
(24, 'Charity Leon', 'bazyqalude@mailinator.com', '', '', 'male', 'active'),
(25, 'bogeaoug', 'yegaiua@gmail.com', '', '', 'male', 'active'),
(26, 'Amyna Rassoul', 'fyguhefyjo@mailinator.com', '+1 (741) 352-8969', 'Voluptas doloremque ', 'male', 'active'),
(27, 'Carol Delacruz', 'hylibeqor@mailinator.com', '71639716989', 'qlhflbqbfliab  vklf lkndf qfnlk88', 'male', 'active'),
(28, 'Carol Bryantjjjjjjjjjjjjjjjjjjjj', 'kuzedima@mailinator.com', '+1 (689) 211-9853', 'Et tempora est iust', 'female', 'active');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
